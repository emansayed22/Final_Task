package Test_Cases;

import java.io.IOException;

import org.testng.annotations.Test;

import Pages.Page_Register;

public class Simple_TC extends Test_Base{
  @Test
  public void GetBrowserAndUrl () throws IOException {
	  
System.out.println(prop.getProperty("URL"));
System.out.println(prop.getProperty("browserName"));
  }
}

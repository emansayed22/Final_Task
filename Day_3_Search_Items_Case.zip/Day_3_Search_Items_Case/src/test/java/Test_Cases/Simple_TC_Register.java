package Test_Cases;

import java.io.IOException;
import java.util.Random;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.Assert;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.assertFalse;

import Pages.Page_Register;

public class Simple_TC_Register extends Test_Base{
	@Test
	public void Register_NewUser () throws IOException, InterruptedException {

		Page_Register p01 = new Page_Register(driver);
		p01.Register_Btn().click();
		Thread.sleep(2000);

		p01.Gender_Btn().click();

		p01.First_Name().sendKeys(prop.getProperty("FirstName"));
		p01.Last_Name().sendKeys(prop.getProperty("LastName"));
		Thread.sleep(2000);

		Select sel = new Select(p01.Date_Birth());
		sel.getOptions().get(new Random().nextInt(sel.getOptions().size())).click();

		Select sel1 = new Select(p01.Mth_Birth());
		sel1.getOptions().get(new Random().nextInt(sel1.getOptions().size())).click();

		Select sel11 = new Select(p01.Year_Birth());
		sel11.getOptions().get(new Random().nextInt(sel11.getOptions().size())).click();

		p01.Email().sendKeys(prop.getProperty("Email"));

		p01.PWD().sendKeys(prop.getProperty("Password"));
		p01.Confirm_PWD().sendKeys(prop.getProperty("ConfirmPassword"));

		p01.Login_Btn().click();

		if (p01.Error_Msg().isEmpty()){
		assertFalse(p01.Success_Msg().isEmpty(), "Your registration completed");
		}
		

	}
}

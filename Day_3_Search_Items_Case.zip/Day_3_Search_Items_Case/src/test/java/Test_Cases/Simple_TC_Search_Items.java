package Test_Cases;

import java.io.IOException;
import java.util.Random;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import org.testng.Assert;
import org.testng.Reporter;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.assertFalse;

import Pages.Page_Register;
import Pages.Page_Search_Items;
import Pages.Page_Login;

public class Simple_TC_Search_Items extends Test_Base{
	@Test
	public void Add_Product () throws IOException, InterruptedException {
		

		WebDriverWait wait   = new WebDriverWait(driver, 10);
		Page_Search_Items p03 = new Page_Search_Items(driver);

		int menus = new Random().nextInt(p03.Menu_Main("").size());
		p03.Menu_Main("").get(menus).click();
		Reporter.log(p03.Menu_Main("").get(menus).getText());


		if(!p03.Sub_category("").isEmpty()){
			int sub_menus = new Random().nextInt(p03.Sub_category("").size());
			Reporter.log(p03.Sub_category("").get(sub_menus).getText());
			p03.Sub_category("").get(sub_menus).click();
		}
		int product = new Random().nextInt(p03.Add_Cart().size());
		Reporter.log(p03.Product_Title(product+1).getText());
		p03.Add_Cart().get(product).click();

		String success_msg= wait.until(ExpectedConditions.visibilityOf(p03.El_01_bar_notification())).getText();
		Reporter.log(success_msg);
		assertTrue(success_msg.contains("The product has been added to your"));


	}
}

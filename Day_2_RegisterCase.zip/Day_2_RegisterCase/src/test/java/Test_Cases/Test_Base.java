package Test_Cases;

import org.testng.annotations.Test;

import Pages.Page_Register;

import org.testng.annotations.BeforeTest;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;

public class Test_Base {


	protected WebDriver driver;
	protected  Properties_Meth prop = new Properties_Meth();


	@BeforeTest
	public void beforeTest() throws IOException {
		if (prop.getProperty("browserName").equals("chrome"))

		{
			String chromePath = System.getProperty("user.dir") + "\\Drivers\\chromedriver.exe";
			System.setProperty("webdriver.chrome.driver", chromePath);
			driver = new ChromeDriver();
		}

		else if (prop.getProperty("browserName").equals("firefox"))
		{
			String fireFoxPath = System.getProperty("user.dir") + "\\Drivers\\geckodriver.exe";
			System.setProperty("webdriver.gecko.driver", fireFoxPath);
			driver = new FirefoxDriver();

		}
		driver.manage().window().maximize();
		driver.navigate().to(prop.getProperty("URL"));

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@AfterMethod
	public void afterMethod() {
		driver.navigate().refresh();
	}


	@AfterTest
	public void afterTest() {
		driver.quit();
	}

}

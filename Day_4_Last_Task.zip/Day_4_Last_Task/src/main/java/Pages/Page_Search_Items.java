package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page_Search_Items extends P_1_Base{


	public Page_Search_Items(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public List<WebElement> Menu_Main(String num){
		return driver.findElements(By.xpath("//ul[@class=\"top-menu notmobile\"]"+num));
	}
	
	public List<WebElement> Sub_category (String num){	
	return driver.findElements(By.xpath("//div[@class=\"sub-category-item\"]"+num));
	}
	
	public List<WebElement> Add_Cart (){	
	return driver.findElements(By.xpath("//input[@value=\"Add to cart\"]"));
	}
	
	public WebElement Product_Title (int num){	
		return driver.findElement(By.xpath("(//h2[@class=\"product-title\"])["+num+"]/a"));
		}
	
	public WebElement El_01_bar_notification ()
	{	
	return driver.findElement(By.xpath("//div[@class=\"bar-notification success\"]"));
	}		
	
	public WebElement El_02_bar_notification_success ()
	{	
	return driver.findElement(By.xpath("//div[@class=\"bar-notification success\"]/p"));
	}

}

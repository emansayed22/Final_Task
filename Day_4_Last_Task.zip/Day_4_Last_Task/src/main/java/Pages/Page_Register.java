package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page_Register extends P_1_Base{


	public Page_Register(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}
	public WebElement Register_Btn(){
		return driver.findElement(By.xpath("//a[@href=\"/register?returnUrl=%2F\"]"));
	}

	public WebElement  Gender_Btn(){
		return driver.findElement(By.xpath("//label[@for=\"gender-female\"]"));
	}

	public WebElement First_Name(){
		return driver.findElement(By.xpath("//input[@name=\"FirstName\"]"));
	}

	public WebElement Last_Name(){
		return driver.findElement(By.xpath("//input[@name=\"LastName\"]"));
	}

	public WebElement Date_Birth(){
		return driver.findElement(By.xpath("//select[@name=\"DateOfBirthDay\"]"));
	}

	public WebElement Mth_Birth(){
		return driver.findElement(By.xpath("//select[@name=\"DateOfBirthMonth\"]"));
	}

	public WebElement Year_Birth(){
		return driver.findElement(By.xpath("//select[@name=\"DateOfBirthYear\"]"));
	}

	public WebElement Email(){
		return driver.findElement(By.xpath("//input[@type=\"email\"and@id=\"Email\"]"));
	}

	public WebElement PWD(){
		return driver.findElement(By.xpath("//input[@name=\"Password\"]"));
	}


	public WebElement Confirm_PWD(){
		return driver.findElement(By.xpath("//input[@id=\"ConfirmPassword\"]"));
	}

	public WebElement Login_Btn(){
		return driver.findElement(By.xpath("//input[@id=\"register-button\"]"));
	}
	
	public List<WebElement> Error_Msg(){
		return driver.findElements(By.xpath("//div[@class=\"message-error validation-summary-errors\"]"));
	}
	
	public List<WebElement> Success_Msg(){
		return driver.findElements(By.xpath("//div[@class=\"result\"]"));
	}
}

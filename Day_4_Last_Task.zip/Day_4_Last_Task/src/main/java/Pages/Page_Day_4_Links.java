package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page_Day_4_Links extends P_1_Base{


	public Page_Day_4_Links(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public WebElement Face_Book(){
		return driver.findElement(By.xpath("//li[@class=\"facebook\"]"));
	}
	
	
	public WebElement Twitter(){
		return driver.findElement(By.xpath("//li[@class=\"twitter\"]"));
	}
	
	public WebElement Demo(){
		return driver.findElement(By.xpath("//li[@class=\"rss\"]"));
	}
	
	public WebElement You_Tube(){
		return driver.findElement(By.xpath("//li[@class=\"youtube\"]"));
	}
	

	

	
	
	


}

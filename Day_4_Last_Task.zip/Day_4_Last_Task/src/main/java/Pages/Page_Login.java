package Pages;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page_Login extends P_1_Base{


	public Page_Login(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public WebElement Login_Btn(){
		return driver.findElement(By.xpath("//a[@class=\"ico-login\"]"));
	}

	public WebElement Email(){
		return driver.findElement(By.xpath("//input[@class=\"email\"]"));
	}

	public WebElement PassWord(){
		return driver.findElement(By.xpath("//input[@class=\"password\"]"));
	}
	public WebElement Submit_Btn(){
		return driver.findElement(By.xpath("//input[@value=\"Log in\"]"));
	}
	
	

}

package Day_4_Tasks;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Random;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.Assert;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.assertFalse;

import Pages.Page_Day_4_Links;
import Pages.Page_Register;

public class Simple_4_FaceBook extends Test_Base{
	
	@Test
	public void Open_Faca_Book () throws IOException, InterruptedException {
		//assertFalse(p01.Success_Msg().isEmpty(), "Your registration completed");
	
		Page_Day_4_Links p04 = new Page_Day_4_Links(driver);
		p04.Face_Book().click();
		
		ArrayList<String> Tabs = new ArrayList<>(driver.getWindowHandles());
		driver.switchTo().window(Tabs.get(1));
		
		System.out.println(driver.getCurrentUrl());
		setProperty("FBURL",driver.getCurrentUrl());
		assertTrue(driver.getCurrentUrl().contains("https://www.facebook.com/nopCommerce"));
	}
	
	
	public void setProperty(String keyname, String Value) throws IOException{
		Properties  prop = new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\data.properties");
		prop.load(fis);
		prop.setProperty(keyname, Value);
		FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir")+"\\data.properties");
		prop.store(fos, "TestComment");
	}

}

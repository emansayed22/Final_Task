package Day_4_Tasks;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class Properties_Meth {
	protected WebDriver driver;
	
	public String getProperty(String keyname) throws IOException{
		Properties  prop = new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\data.properties");
		prop.load(fis);
		return	prop.getProperty(keyname);
	}
	
	
	public void setProperty(String keyname, String Value) throws IOException{
		Properties  prop = new Properties();
		FileInputStream fis = new FileInputStream(System.getProperty("user.dir")+"\\data.properties");
		prop.load(fis);
		prop.setProperty(keyname, Value);
		FileOutputStream fos = new FileOutputStream(System.getProperty("user.dir")+"\\data.properties");
		prop.store(fos, "TestComment");
	}

}

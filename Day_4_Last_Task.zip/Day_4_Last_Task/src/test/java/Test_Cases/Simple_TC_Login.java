package Test_Cases;

import java.io.IOException;
import java.util.Random;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;
import org.testng.Assert;
import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;
import static org.testng.Assert.assertFalse;

import Pages.Page_Register;
import Pages.Page_Login;

public class Simple_TC_Login extends Test_Base{
	@Test
	public void Login () throws IOException, InterruptedException {

		Page_Login p02 = new Page_Login(driver);
		p02.Login_Btn().click();
		p02.Email().sendKeys(prop.getProperty("Email"));
		p02.PassWord().sendKeys(prop.getProperty("Password"));
		p02.Submit_Btn().click();
		Thread.sleep(2000);
	

	


//		Select sel11 = new Select(p01.Year_Birth());
//		sel11.getOptions().get(new Random().nextInt(sel11.getOptions().size())).click();
//
//		
//
//		p01.Login_Btn().click();
//
//		if (p01.Error_Msg().isEmpty()){
//		assertFalse(p01.Success_Msg().isEmpty(), "Your registration completed");
	//	}
		

	}
}

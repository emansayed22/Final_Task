package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Page_Search extends P_1_Base{
	

	public Page_Search(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	public WebElement Search_element(){
  	   return driver.findElement(By.xpath("//input[@id=\"small-searchterms\"]"));
     }

	
	
	
}
